sap.ui.define([
	"bpoverview/test/unit/controller/App.controller"
], function () {
	"use strict";
});
