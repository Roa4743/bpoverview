sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
    function (Controller, MessageBox) {
        "use strict";

        return Controller.extend("bpoverview.controller.BPDetails", {

            onInit: function () {
                var oExitButton = this.getView().byId("adptexitfsbtn"),
				oEnterButton = this.getView().byId("adptenterfsbtn");

                this.oRouter = this.getOwnerComponent().getRouter();
                this.oLayoutModel = this.getOwnerComponent().getModel("layout");
                
                this.oRouter.getRoute("BusinessPartners").attachPatternMatched(this._onBPMatched, this);
			    this.oRouter.getRoute("BPDetails").attachPatternMatched(this._onBPMatched, this);

                [oExitButton, oEnterButton].forEach(function (oButton) {
                    oButton.addEventDelegate({
                        onAfterRendering: function () {
                            if (this.bFocusFullScreenButton) {
                                this.bFocusFullScreenButton = false;
                                oButton.focus();
                            }
                        }.bind(this)
                    });
                }, this);
            },

            handleBPFullScreen: function () {
                this.bFocusFullScreenButton = true;
                var sNextLayout = this.oLayoutModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
                this.oRouter.navTo("BPDetails", {
                    layout: sNextLayout,
                    bp: this._bp,
                    uuid: this._uuid,
                    active: this._active
                });
            },

            handleBPExitFullScreen: function () {
                this.bFocusFullScreenButton = true;
                var sNextLayout = this.oLayoutModel.getProperty("/actionButtonsInfo/midColumn/exitFullScreen");
                this.oRouter.navTo("BPDetails", {
                    layout: sNextLayout,
                    bp: this._bp,
                    uuid: this._uuid,
                    active: this._active
                });
            },

            handleBPClose: function () {
                var sNextLayout = this.oLayoutModel.getProperty("/actionButtonsInfo/midColumn/closeColumn");
                this.oRouter.navTo("BusinessPartners", {
                    layout: sNextLayout
                });
            },

            onPressButton: function () {
                alert(this.getView().getBindingContext().getProperty("BusinessPartner"));
            },

            _onBPMatched: function (oEvent) {
                //when page is refreshed - reset the navigation
                if (this.getOwnerComponent().getHelper().getCurrentUIState().layout === "OneColumn") {
                    this.oRouter.navTo("BusinessPartners", {
                        layout: "OneColumn"
                    });
                }
                
                this._bp = oEvent.getParameter("arguments").bp || this._bp || "0";
                this._uuid = oEvent.getParameter("arguments").uuid || this._uuid || "0";;
                this._active = oEvent.getParameter("arguments").active || this._active || "true";
                this.getView().bindElement({
                    path: "/C_BusinessPartner(BusinessPartner='" + this._bp + "',DraftUUID=guid'" + this._uuid + "',IsActiveEntity=" + this._active + ")"
                });
            }

        });
    });