sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
    function (Controller, MessageBox, Filter, FilterOperator) {
        "use strict";

        return Controller.extend("bpoverview.controller.BusinessPartners", {

            onInit: function () {
                this.oRouter = this.getOwnerComponent().getRouter();
            },

            onBPSearch: function () {
                var oTable = this.byId("adptbptab");
                var oBPSearchKey = this.byId("adptbpinput").getValue().trim();

                var oFilter =  new Filter({
                    path: "FullName",
                    operator: FilterOperator.Contains,
                    value1: oBPSearchKey
                });

                oTable.getBinding("items").filter(oFilter);
            },

            onBPPress: function (oEvent) {
                var oItem = oEvent.getSource();
                var sBPNum = oItem.getBindingContext().getProperty("BusinessPartner");
                var sUuid = oItem.getBindingContext().getProperty("DraftUUID");
                var sActive = oItem.getBindingContext().getProperty("IsActiveEntity");
                var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(1);
                this.oRouter.navTo("BPDetails", {
                    layout: oNextUIState.layout,
                    bp: sBPNum,
                    uuid: sUuid,
                    active: sActive
                });
            }

        });
    });